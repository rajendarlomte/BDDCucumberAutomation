package com.Listeners;

import org.apache.log4j.Logger;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;



public class Listners implements ITestListener
{
	Logger log = Logger.getLogger(Listners.class);
	@Override
	public void onTestStart(ITestResult result) {
		System.out.print(result.getName()+"Testcase started.");
		log.info("Testcase started"+result.getName());
		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.print(result.getName()+"Testcase started.");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.print(result.getName()+"Testcase Failed.");
		log.info(result.getName()+"Testcase Failed");
		
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.print(result.getName()+"Testcase started.");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

}
