package com.StepDefinition;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.GenericLib.DatabaseFunction;
import com.GenericLib.GenericFunctions;
import com.GenericLib.GetWebDriverInstance;
import com.GenericLib.Synchronization;
import com.TestRunner.TestNGRunCucumberTest;
import com.Listeners.Listners;
import com.GenericLib.Utilities;
import com.GenericLib.Extent_Reports;

import cucumber.api.java.en.Given;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@org.testng.annotations.Listeners(com.Listeners.Listners.class)
public class PG_SearchFlight extends TestNGRunCucumberTest
{
		
	//public WebDriver driver;
		DatabaseFunction db = new DatabaseFunction();
	//	GenericFunctions GFObj = new GenericFunctions();
		Logger log = Logger.getLogger(PG_SearchFlight.class);
		public List<String> lstObject, lstTestData;
		protected String baseURL = "https://www.cleartrip.com";
		WebElement source,destination,dateSearch,searchFlight,duration,bookTicket;
		String Title, ExpectedTitle;
		
		
		public PG_SearchFlight() 
	    {  
			try {  
	    	lstTestData = db.getTestDataObject("Select * from TDFlight", "Input");
	    	lstObject = db.getTestDataObject("Select * from OR_FlightBooking", "ObjectRepository");
	    } catch (Exception exc) {		
	    	System.out.println("Exception in Constructor." + exc.getMessage());    }
		}    
		
		@Given("^user is on cleartrip home page\\.$")
		public void flightBooking() throws Throwable
	    {    	
			System.out.println("Given annotation is executed.");
//		Title = (driver.getTitle());
//		ExpectedTitle = "#1 Site for Booking Flights, Hotels, Packages, Trains & Local activities.";
//		if(Title.contentEquals(ExpectedTitle)) 
//			Extent_Reports.executionLog("Pass","User is on the cleartrip page.",driver);
//	else		
//			Extent_Reports.executionLog("Fail","User is not on the cleartrip page",driver);
		
//		throw new PendingException();
	    }

		@When("^user searches for a flight from Source to Destination$")
		public void user_searches_for_a_flight_from_Source_In_to_Destination() throws Throwable {
			source=Utilities.returnElement(driver, lstObject.get(1), lstObject.get(2));
			destination=Utilities.returnElement(driver, lstObject.get(4), lstObject.get(5));
			dateSearch=Utilities.returnElement(driver, lstObject.get(7), lstObject.get(8));
			searchFlight=Utilities.returnElement(driver, lstObject.get(10), lstObject.get(11));
			
			if (source.isEnabled()) {
				source.click();
				source.sendKeys(lstTestData.get(0));
//				Extent_Reports.executionLog("Pass","User is able to provide the source location.",driver);
//			}
//			else		{
//				Extent_Reports.executionLog("Fail","User not able to select the Source to book the ticket",driver);
//	    }	
	    	if (destination.isDisplayed())
	    	{   destination.click();
	    	destination.sendKeys(lstTestData.get(1));
	    	 //	Extent_Reports.executionLog("Pass","Destination selected successfully",driver);
			}
//			else		
//				Extent_Reports.executionLog("Fail","User not able to select the destination to book the ticket",driver);
	    	
	    	if (dateSearch.isEnabled())
	    	{
	    	 	dateSearch.click();
	    	 	dateSearch.sendKeys(lstTestData.get(2));
	    	 	//Extent_Reports.executionLog("Pass","Date selected successfully",driver);
			}
//			else		
//				Extent_Reports.executionLog("Fail","User not able to select the Date to book the ticket",driver);
	    	
	    	
	    	if(searchFlight.isEnabled())
	    	{ 	searchFlight.click();
	    	Synchronization.waitForPageLoad(driver);
	    	Thread.sleep(10000);
//	    		Extent_Reports.executionLog("Pass","Search flights clicked successfully",driver);
			}
//			else		
//				Extent_Reports.executionLog("Fail","User not able to select the Date to book the ticket",driver);
	    	
		    throw new PendingException();
			}
		}

		@And("^sort the cost and duration in ascending order$")
		public void sort_the_cost_and_duration_in_ascending_order() throws Throwable {
			duration=Utilities.returnElement(driver, lstObject.get(13), lstObject.get(14));
		    if (duration.isEnabled())
		    {
		    	duration.click();
		    	Synchronization.waitForPageLoad(driver);
		    	Thread.sleep(5000);
//		    	Extent_Reports.executionLog("Pass","Flight duration sorted successfully",driver);
			}
//			else		
//				Extent_Reports.executionLog("Fail","Flight duration is not sorted",driver);
		    throw new PendingException();
		}

		@Then("^book the cheapest and fastest flight available$")
		public void book_the_cheapest_and_fastest_flight_available() throws Throwable {
			 bookTicket=Utilities.returnElement(driver, lstObject.get(16), lstObject.get(17));
			    if (bookTicket.isEnabled())
			    {
			    	bookTicket.click();
//			    	Extent_Reports.executionLog("Pass","Flight booking clicked successfully",driver);
				}
//				else		
//					Extent_Reports.executionLog("Fail","Flight booking is not showing",driver);
		    throw new PendingException();
		}
}
