package com.TestRunner;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.Listeners.Listners;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import cucumber.api.testng.TestNGCucumberRunner;

@CucumberOptions(features = { "src/test/java/com/features" }, glue = { "com.StepDefinition" }, plugin = { "pretty",
        "json:target/cucumber/cucumber.json" })

public class TestNGRunCucumberTest extends AbstractTestNGCucumberTests {

	private static String OS = System.getProperty("os.name").toLowerCase();
	private static String genericPath = System.getProperty("user.dir").concat("/src/test/resources/DriverExecutable/");
    protected String baseURL = "https://www.cleartrip.com";
    protected static WebDriver driver = null;
    private TestNGCucumberRunner testNGCucumberRunner;
    

	public static ChromeOptions chromeOption() {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("disable-infobars");
		options.setExperimentalOption("useAutomationExtension", false);
		options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		return options;
	}
	
    @BeforeClass
    @Parameters(value = { "browserName", "version" })
    public void beforeClass(String browserName, float version) throws InterruptedException 
    {
    	switch (browserName.toLowerCase()) 
    	{

			case "chrome":

    	
		    	if (browserName.equalsIgnoreCase("chrome") && (OS.indexOf("mac") >= 0)) 
				{
		    		System.out.println(browserName);
					System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver");
					driver = new ChromeDriver(chromeOption()); 
				}
				else
				{
					System.setProperty("webdriver.chrome.driver", genericPath + "chromedriver.exe");
		
					driver = new ChromeDriver(chromeOption()); 
				}
		    	break;
		    	
			case "firefox":
			
				if(browserName.equalsIgnoreCase("firefox") && (OS.indexOf("mac") >= 0) ) 
				{
					System.out.println("FF");
					System.setProperty("webdriver.gecko.driver", genericPath + "geckodriver");
					driver = new FirefoxDriver();
		
				}
				else
				{
					System.setProperty("webdriver.gecko.driver", genericPath + "geckodriver.exe");
					driver = new FirefoxDriver(); 
				}

				break;
				
			case "safari":

					if (browserName.equalsIgnoreCase("safari")) 
						{
							System.setProperty("webdriver.safari.driver", "/usr/local/bin/SafariDriver.safariextz");	
							driver = new SafariDriver(); 
						}
					break;
    	}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.navigate().to(baseURL);
		Thread.sleep(5000);
		
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	} 


    @AfterClass
    public void tearDown() {
        driver.quit();
        testNGCucumberRunner.finish();
    }
}