package com.GenericLib;

import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;


public class GetWebDriverInstance 
{
	public   WebDriver driver ; 
	
	private static String OS = System.getProperty("os.name").toLowerCase();
	public static String downloadPath = System.getProperty("user.dir") + "\\Downloads";
	private static String genericPath = System.getProperty("user.dir").concat("/src/test/resources/DriverExecutable/");
    public String browserName;
	public static FirefoxOptions firefoxOption() {
		FirefoxOptions option = new FirefoxOptions();
		option.setHeadless(true);
		return option;
	}

	public static ChromeOptions chromeOption() {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("disable-infobars");
		options.setExperimentalOption("useAutomationExtension", false);
		options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		return options;
	}

	
	@Parameters({"browserName"})
	public GetWebDriverInstance(String browser)
	{
		browserName = browser;
	}
	public GetWebDriverInstance()
	{
	}
	public void InitDriver() 
	{
		System.out.println("HI");
		if (browserName.equalsIgnoreCase("chrome") && (OS.indexOf("mac") >= 0)) 
		{
			System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver");
			driver = new ChromeDriver(chromeOption()); 
		}
		else
		{
			System.setProperty("webdriver.chrome.driver", genericPath + "chromedriver.exe");

			driver = new ChromeDriver(chromeOption()); 
		}

		if(browserName.equalsIgnoreCase("firefox") && (OS.indexOf("mac") >= 0) ) 
		{
			System.setProperty("webdriver.gecko.driver", genericPath + "geckodriver");
			driver = new FirefoxDriver();

		}
		else
		{
			System.setProperty("webdriver.gecko.driver", genericPath + "geckodriver");
			driver = new FirefoxDriver(firefoxOption()); 
		}

		

	if (browserName.equalsIgnoreCase("safari")) {
		System.setProperty("webdriver.safari.driver", "/usr/local/bin/SafariDriver.safariextz");	
		driver = new SafariDriver(); 
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.navigate().to("http://demo.nopcommerce.com/");
		System.out.println("Driver");
	} 

	@AfterSuite
	public void stopDriver() 
	{
		driver.quit();
	}

	// take screenshot when test case fail and add it in the Screenshot folder
	
}
