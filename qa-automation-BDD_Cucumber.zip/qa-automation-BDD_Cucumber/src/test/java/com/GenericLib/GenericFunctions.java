package com.GenericLib;

import java.util.Hashtable;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.interactions.internal.Locatable;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

public class GenericFunctions {
	static WebDriver drivers;
	static WebDriverWait wait;
	static boolean element;
	Logger log = Logger.getLogger(GenericFunctions.class);




	// ==================== VALIDATING THE TEXTBOXES TEXT WITH ENTERED TEXT(Two
	// strings
	// validation)=================================================================

	public void ValidatingTwoStrings(String objActualText, String ExpectedText, WebDriver driver) throws Exception {
		SoftAssert soft_Assert = new SoftAssert();
		drivers = driver;
		try {
			Assert.assertEquals(objActualText.trim(), ExpectedText);
			Extent_Reports.executionLog("PASS",
					Extent_Reports.logExpected + ExpectedText.trim() + Extent_Reports.logActual + objActualText.trim(),
					driver);
		} catch (Throwable t) {
			soft_Assert.fail("Actual content '" + objActualText.trim() + "' And Expected Content '" + ExpectedText
					+ "' do not match");
			Extent_Reports.executionLog("FAIL",
					Extent_Reports.logExpected + ExpectedText.trim() + Extent_Reports.logActual + objActualText.trim(),
					driver);
		}
	}

//==================== VALIDATING THE CHECK BOX WITH ENTERED TEXT =================================================================

	public void ValidatingCheckbox(WebElement objCheckbox, String ExpectedText, WebDriver driver) throws Exception {
		try {
			if (ExpectedText.equalsIgnoreCase("Yes")) {

				Assert.assertTrue(objCheckbox.isSelected() == true);
				Extent_Reports.executionLog("PASS", "Checkbox is checked", driver);
			} else if (ExpectedText.equalsIgnoreCase("No")) {
				Assert.assertTrue(objCheckbox.isSelected() == false);
				Extent_Reports.executionLog("PASS", "Checkbox is unchecked", driver);
			}
		} catch (Throwable t) {
			Extent_Reports.executionLog("FAIL", "Checkbox is not working as expected or Verify data in test data file",
					driver);
		}

	}

//==================== VERIFY ELEMENT STATES ====================================================================

	public boolean VerifyElementActions(WebDriver driver, WebElement objectID, String objectProperty) throws Exception {
		try {
			

			if (objectProperty.equalsIgnoreCase("Enabled")) {
				element = objectID.isEnabled();
				Extent_Reports.executionLog("PASS", "Element" + " " + objectID.getText() + " " + objectProperty,
						driver);
			}

			else if (objectProperty.equalsIgnoreCase("displayed")) {
				element = objectID.isDisplayed();
				Extent_Reports.executionLog("PASS", "Element" + " " + objectID.getText() + " " + objectProperty,
						driver);
			} else if (objectProperty.equalsIgnoreCase("Selected")) {
				element = objectID.isSelected();
				Extent_Reports.executionLog("PASS", "Element" + " " + objectID.getText() + " " + objectProperty,
						driver);
			}
		}

		catch (Throwable t) {
			Extent_Reports.executionLog("FAIL",
					"Element" + " " + objectID.getText() + " " + "Not" + " " + objectProperty, driver);
		}

		return false;

	}


	public void GetclassName(String nameofCurrClass) {
		// nameofCurrClass = getClass().getSimpleName();
		log.info("\n\n ************************** Starting " + nameofCurrClass);
	}

	public void GetmethodName(String nameofCurrMethod) {
		// String nameofCurrMethod = new Throwable().getStackTrace()[0].getMethodName();
		log.info("\n ~~~~~~~ Starting " + nameofCurrMethod);
	}

	

	// =================Method to get text from form
	
	// -----------------------Java Script Excecutor Click----------------
	/**public void JSEClick(WebDriver driver, WebElement locator) throws Exception {

		if (driver instanceof ChromeDriver || GetWebDriverInstance.browserName.equalsIgnoreCase("Chrome")) {
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", locator);
		} else {
			locator.click();
		}
	}**/

	// ===================================================================================================================================

	public Hashtable<String, String> getContextFromNetworkTabCalls(WebDriver driver, String EventName) throws Exception {
		String netData = null;
		String scriptToExecute, strTrackCall, strTrackCallAttributes, strUser_Consent = null;
		String[] arrTrackCallAttributes, arrSegmentTrack = null;
		Hashtable<String, String> htbl = new Hashtable<String, String>();
		try {
			scriptToExecute = "var performance = window.performance || window.mozPerformance || window.msPerformance || window.webkitPerformance || {}; var network = performance.getEntries() || {}; return network;";
			netData = ((JavascriptExecutor) driver).executeScript(scriptToExecute).toString();

//			Thread.sleep(3000);
			String segmentData[] = netData.split("name=https");

			String word = "ptq.gif?id";
			for (int iLoop = 0; iLoop < segmentData.length; iLoop++) {
				// if match found increase count
				if (segmentData[iLoop].contains(word)) {
					strTrackCall = segmentData[iLoop].substring(segmentData[iLoop].lastIndexOf("ptq.gif?id") + 8)
							.replace("+", " ");

					if (strTrackCall.contains(EventName)) {
						htbl.clear();
						strUser_Consent = null;
						arrTrackCallAttributes = strTrackCall.split("&", 0);
						for (String aStr : arrTrackCallAttributes) {
							arrSegmentTrack = aStr.split("=", 0);
							if (arrSegmentTrack.length > 1) // Verifying the length after split.
							{
								if (arrSegmentTrack[0].trim().equalsIgnoreCase("user_consent")) {
									strUser_Consent = strUser_Consent + "," + arrSegmentTrack[1].trim();
								} else {
									htbl.put(arrSegmentTrack[0].replace("null,", ""),
											arrSegmentTrack[1].replace("null,", ""));
								}
							} else {
								break;
							}
						}
						htbl.put("user_consent", strUser_Consent.replace("null,", ""));
					}
				}
			}
//			System.out.println(htbl);
		} catch (Exception exc) 
		{
			exc.printStackTrace();
			Extent_Reports.executionLog("Fail",Extent_Reports.logExpected +
					"Should execute getContextFromNetworkTabCalls"+ Extent_Reports.logActual + 
					"Didn't execute getContextFromNetworkTabCalls ",driver);
			System.out.println("Exception in getContextFromNetworkTabCalls:" + exc.getMessage() + ":" + exc.getCause());
		}
		return htbl;
	}

	public static boolean isNullOrEmpty(String str) {
		if (str != null && !str.isEmpty())
			return false;
		return true;
	}
}
