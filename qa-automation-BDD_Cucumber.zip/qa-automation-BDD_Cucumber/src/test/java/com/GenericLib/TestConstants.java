package com.GenericLib;

public class TestConstants {
	
	public static final String REQUIRED = "Required";
	public static final String EMPTYSTRING = "";
	public static final String UKLANGUAGEKEYWORD = "/en-gb/";
	public static final String HANAWEBSITETITLE = "Hana at Park District";
	public static final String OTHERLANGUAGEKEYWORD="/fr-fr/";
	public static final String DEMANDBASETAG="tag.demandbase";
	public static final String SNNTAXERRORS="SyntaxError";
	
	public static final String HANAFACEBOOKLINK="https://www.facebook.com/HanaSpaces/";
	public static final String HANALINKEDINLINK="https://www.linkedin.com/company/hanaspaces/";
	public static final String HANAINSTAGRAMLINK="https://www.instagram.com/hanaspaces/";
	public static final String HANATWITTERLINK="https://twitter.com/HanaSpaces";
	public static final String HANAUSBLOGQALINK="https://blog-qa.yourhana.com/";
	public static final String HANAUSBLOGQALINKBEFOREREDIRECTION="https://blog.yourhana.com/hana-qa";
	public static final String HANAUKQALINK="https://hana-qa.yourhana.com/en-gb/";
	public static final String HANAUKPRODLINK="https://www.yourhana.com/en-gb/";
	public static final String HANAUSQALINK="https://hana-qa.yourhana.com/";
	public static final String HANAUSQA2LINK="https://hana-qa2.yourhana.com/";
	public static final String HANAUSPRODLINK="https://yourhana.com/";
	public static final String HANAFAQQALINK="https://faq-qa.yourhana.com/";
	public static final String HANAQAKEYWORD="hana-qa";
	public static final Integer totalDaysAvailable=21;
	public static final String DALLASURLEXTENSION="dallas/park-district/";
	public static final String IRVINEURLEXTENSION="orange-county/park-place/";
	public static final String HAMMERSMITHURLEXTENSION="london/hammersmith/";
	public static final String SMAURLEXTENSION="london/st-mary-axe/";
	
	
	
	//public static final String SNNTAXERRORS="SyntaxError";


}
