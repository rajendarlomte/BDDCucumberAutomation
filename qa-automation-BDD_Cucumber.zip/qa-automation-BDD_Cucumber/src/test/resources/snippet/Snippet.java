package snippet;

public class Snippet {
	ActivationPage	com.nbcd.Test.TCActivationPage_URLRoutingforactivationpage_NBCRESP3518	Chrome	No
	ShowHomePage	com.nbcd.Test.TCShowHomePage_VerifyGuestcalenderwhentherearenoepisode_NBCRESP4107	Chrome	No
	
}

